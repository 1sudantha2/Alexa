global.botPhoneNumber = null;
global.connectionStatus = 'Offline';
